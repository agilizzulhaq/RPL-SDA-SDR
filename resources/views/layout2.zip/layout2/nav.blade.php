<a id="menu" href="/dashboard" tabindex="0" class="cursor-pointer text-black hover:text-black no-underline bg-[#D9D9D9] flex items-center pl-[17px] hover:bg-[#FFFFFF] w-full">
    <span class="material-icons h-23 mt-2 " style="font-size: 40px;">home</span>
    <p class="text-xl font-bold mt-3 ml-5">Dashboard</p>
</a>
<a id="menu" href="/sda" tabindex="0" class="cursor-pointer text-black hover:text-black no-underline bg-[#D9D9D9] flex items-center pl-[17px] hover:bg-[#FFFFFF]">
    <span class="material-icons h-23 mt-2 " style="font-size: 40px;">vaccines</span>
    <p class="text-xl font-bold mt-3 ml-5">Sumber Daya Alat</p>
</a>
<a id="menu" href="/sdr" tabindex="0" class="no-underline cursor-pointer text-black hover:text-black bg-[#D9D9D9] flex pl-[17px]  hover:bg-[#FFFFFF]">
    <span class="material-icons h-23 mt-2 " style="font-size: 40px;">apartment</span>
    <p class="text-xl font-bold  mt-3 ml-5">Sumber Daya Ruangan</p>
</a>